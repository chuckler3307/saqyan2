# ZORKO — how to open the website

## Just double-click `index.html`

That's it. No localhost, no install, no build step.

The site is one self-contained file written in **React (plain JavaScript)** — no TypeScript.
Chrome opens it straight from your folder.

---

## Folder structure (keep it like this)

```
ZORKO/
├── index.html          ← double-click this
└── public/
    └── images/         ← the 10 ZORKO dish photos
        ├── burger.jpg
        ├── pizza.jpg
        ├── mojito.jpg
        ├── fries.jpg
        ├── wrap.jpg
        ├── bun.jpg
        ├── momos.jpg
        ├── kulhad.jpg
        ├── toastie.jpg
        └── nachos.jpg
```

Keep `index.html` and the `public` folder together and everything works.

---

## Do I need internet?

Yes, keep it on for the best look. The page loads from the internet:

- React (via CDN)
- Google Fonts (Bebas Neue, Outfit, Caveat)
- The additional menu photos

The 10 main ZORKO dish photos are stored locally and work regardless.

---

## Editing the site

Open `index.html` in Notepad / VS Code. Everything lives in that one file:

| What you want to change | Where to look |
| --- | --- |
| Colours | `:root { --zorko: #ff6b00; ... }` at the top of `<style>` |
| Menu dishes & prices | the `MENU` array inside `<script type="text/babel">` |
| Story chapters | the `STORY` array |
| "Why choose ZORKO" cards | the `WHY` array |
| Stats (500+, 250+ …) | the `STATS` array |
| Cities | the `CITIES` array |

Save the file and refresh Chrome (Ctrl+R). No rebuild needed.

---

## Troubleshooting

**Page is blank / unstyled**
Check your internet connection — React and the fonts load from a CDN. Then hard-refresh with Ctrl+Shift+R.

**Dish photos missing**
Make sure the `public/images` folder sits next to `index.html` and still has all 10 `.jpg` files.

**Want to put it on the web?**
Upload `index.html` plus the `public` folder to any host (Netlify, GitHub Pages, Hostinger, your cPanel `public_html`). It works as-is.
