import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowRight,
  Award,
  Check,
  ChefHat,
  ChevronLeft,
  ChevronRight,
  Cpu,
  Factory,
  Globe2,
  Heart,
  IndianRupee,
  MapPin,
  Megaphone,
  Menu as MenuIcon,
  Palette,
  Phone,
  Play,
  Search,
  Sparkles,
  Star,
  Store,
  TrendingUp,
  UtensilsCrossed,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import {
  BOGO,
  CATEGORIES,
  CITIES,
  IMAGES,
  MENU,
  PACKAGE_ITEMS,
  SIGNATURES,
  STATS,
  STORY,
  WHY,
  type Badge,
  type MenuItem,
} from "./data";

const NAV = [
  { href: "#menu", label: "Menu" },
  { href: "#why", label: "Why ZORKO" },
  { href: "#story", label: "Our Story" },
  { href: "#offers", label: "Meals" },
  { href: "#franchise", label: "Franchise" },
  { href: "#presence", label: "Outlets" },
];

function BadgePill({ kind }: { kind: Badge }) {
  const map: Record<Badge, { label: string; cls: string }> = {
    best: { label: "Best Seller", cls: "bg-rose-500 text-white" },
    new: { label: "New Launch", cls: "bg-emerald-500 text-white" },
    must: { label: "Must Try", cls: "bg-amber-400 text-stone-900" },
    spicy: { label: "Spicy", cls: "bg-orange-600 text-white" },
    kids: { label: "Kids Special", cls: "bg-sky-400 text-stone-900" },
    star: { label: "★ Signature", cls: "bg-white/90 text-stone-900" },
  };
  const b = map[kind];
  return (
    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${b.cls}`}>
      {b.label}
    </span>
  );
}

function WhyIcon({ name }: { name: string }) {
  const wrap = "h-14 w-14 rounded-2xl flex items-center justify-center";
  const icons: Record<string, ReactNode> = {
    wallet: (
      <div className={`${wrap} bg-orange-100 text-orange-600`}>
        <Wallet className="h-7 w-7" />
      </div>
    ),
    factory: (
      <div className={`${wrap} bg-sky-100 text-sky-600`}>
        <Factory className="h-7 w-7" />
      </div>
    ),
    chef: (
      <div className={`${wrap} bg-rose-100 text-rose-600`}>
        <ChefHat className="h-7 w-7" />
      </div>
    ),
    growth: (
      <div className={`${wrap} bg-emerald-100 text-emerald-600`}>
        <TrendingUp className="h-7 w-7" />
      </div>
    ),
    palette: (
      <div className={`${wrap} bg-violet-100 text-violet-600`}>
        <Palette className="h-7 w-7" />
      </div>
    ),
    menu: (
      <div className={`${wrap} bg-amber-100 text-amber-700`}>
        <UtensilsCrossed className="h-7 w-7" />
      </div>
    ),
    megaphone: (
      <div className={`${wrap} bg-fuchsia-100 text-fuchsia-600`}>
        <Megaphone className="h-7 w-7" />
      </div>
    ),
    cpu: (
      <div className={`${wrap} bg-cyan-100 text-cyan-700`}>
        <Cpu className="h-7 w-7" />
      </div>
    ),
  };
  return <>{icons[name]}</>;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#top" className="group flex flex-col leading-none">
      <span className={`font-display tracking-[0.12em] text-[#ff6b00] drop-shadow-[0_2px_0_rgba(0,0,0,0.25)] ${compact ? "text-3xl" : "text-4xl md:text-5xl"}`}>
        ZORKO
        <span className="align-top text-[10px]">®</span>
      </span>
      <span className={`mt-0.5 font-semibold uppercase tracking-[0.28em] text-white ${compact ? "text-[8px]" : "text-[9px] md:text-[10px]"}`}>
        Brand of Food <span className="text-[#ffb020]">lovers</span>
      </span>
    </a>
  );
}

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [openNav, setOpenNav] = useState(false);
  const [cat, setCat] = useState("all");
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<MenuItem | null>(null);
  const [chapter, setChapter] = useState(0);
  const [sent, setSent] = useState(false);
  const [splash, setSplash] = useState(true);
  const [splashOut, setSplashOut] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setSplashOut(true), 1100);
    const t2 = setTimeout(() => setSplash(false), 1700);
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MENU.filter((m) => {
      const okCat = cat === "all" || m.category === cat;
      const okQ = !q || m.name.toLowerCase().includes(q) || m.desc.toLowerCase().includes(q);
      return okCat && okQ;
    });
  }, [cat, query]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  const ch = STORY[chapter];

  return (
    <div id="top" className="grain-dark min-h-screen text-stone-100">
      {splash && (
        <div
          className={`fixed inset-0 z-[80] flex items-center justify-center bg-[#0d0b0a] transition-opacity duration-500 ${
            splashOut ? "opacity-0" : "opacity-100"
          }`}
        >
          <div className="text-center">
            <div className="font-display shimmer-text text-7xl tracking-[0.14em] md:text-8xl">ZORKO</div>
            <p className="mt-3 text-xs uppercase tracking-[0.5em] text-[#ffb020]">Brand of food lovers</p>
          </div>
        </div>
      )}

      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled ? "border-b border-white/10 bg-[#0d0b0a]/85 backdrop-blur-xl" : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 md:px-8">
          <Logo compact />
          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((n) => (
              <a key={n.href} href={n.href} className="text-sm font-medium text-stone-300 transition hover:text-[#ff6b00]">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <a
              href="#franchise"
              className="hidden rounded-full bg-[#ff6b00] px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-orange-600/30 transition hover:bg-[#e25100] md:inline-flex"
            >
              Get Franchise
            </a>
            <button
              type="button"
              className="rounded-full border border-white/15 p-2 lg:hidden"
              onClick={() => setOpenNav(true)}
              aria-label="Open menu"
            >
              <MenuIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {openNav && (
        <div className="fixed inset-0 z-[60] bg-[#0d0b0a]/95 p-8 backdrop-blur-xl lg:hidden">
          <div className="flex justify-between">
            <Logo compact />
            <button type="button" onClick={() => setOpenNav(false)} aria-label="Close menu">
              <X className="h-7 w-7" />
            </button>
          </div>
          <div className="mt-12 flex flex-col gap-6">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpenNav(false)}
                className="font-display text-4xl tracking-wide text-white"
              >
                {n.label}
              </a>
            ))}
            <a
              href="#franchise"
              onClick={() => setOpenNav(false)}
              className="mt-4 inline-flex w-fit rounded-full bg-[#ff6b00] px-6 py-3 font-semibold"
            >
              Get Franchise
            </a>
          </div>
        </div>
      )}

      <section className="relative min-h-[100svh] overflow-hidden noise">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 h-full w-full object-cover object-center"
        >
          <source src="/videos/clip.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d0b0a] via-[#0d0b0a]/85 to-[#0d0b0a]/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0d0b0a] via-transparent to-[#0d0b0a]/50" />

        <div className="relative mx-auto flex min-h-[100svh] max-w-7xl flex-col justify-end px-5 pb-16 pt-28 md:justify-center md:px-8 md:pb-24">
          <div className="max-w-2xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#ff6b00]/40 bg-[#ff6b00]/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#ffb020]">
              <Sparkles className="h-3.5 w-3.5" />
              Shark Tank India · Forbes 30 Under 30
            </div>
            <h1 className="font-display text-[4.4rem] leading-[0.82] tracking-[0.06em] text-white sm:text-[7rem] md:text-[8.5rem]">
              <span className="shimmer-text">ZORKO</span>
            </h1>
            <p className="mt-2 font-semibold uppercase tracking-[0.42em] text-[#ffb020]">Brand of food lovers</p>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-stone-300 md:text-xl">
              India’s fastest & largest growing pure vegetarian QSR. Affordable food. Premium experience. 80+ dishes. Zero compromise on taste.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#menu"
                className="inline-flex items-center gap-2 rounded-full bg-[#ff6b00] px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-white shadow-xl shadow-orange-700/40 transition hover:bg-[#e25100]"
              >
                Explore Menu <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="#franchise"
                className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-white backdrop-blur transition hover:bg-white/10"
              >
                Own a ZORKO
              </a>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 text-sm text-stone-400">
              <span className="inline-flex items-center gap-2">
                <Heart className="h-4 w-4 text-[#ff6b00]" /> 100% Pure Veg
              </span>
              <span className="inline-flex items-center gap-2">
                <Store className="h-4 w-4 text-[#ff6b00]" /> 500+ Outlets
              </span>
              <span className="inline-flex items-center gap-2">
                <Globe2 className="h-4 w-4 text-[#ff6b00]" /> 250+ Cities
              </span>
            </div>
          </div>
        </div>

        <div className="pointer-events-none absolute right-8 top-1/2 hidden -translate-y-1/2 lg:block">
          <div className="relative h-[420px] w-[420px]">
            <div className="absolute inset-8 rounded-full border border-white/10" />
            <div className="spin-slow absolute inset-0 rounded-full border border-dashed border-[#ff6b00]/40" />
            <img
              src={IMAGES.pizza}
              alt="ZORKO pizza"
              className="floaty absolute -left-6 top-16 h-28 w-28 rounded-2xl object-cover shadow-2xl ring-2 ring-white/10"
            />
            <img
              src={IMAGES.mojito}
              alt="ZORKO mojito"
              className="floaty-slow absolute -right-4 top-8 h-32 w-24 rounded-2xl object-cover shadow-2xl ring-2 ring-white/10"
            />
            <img
              src={IMAGES.fries}
              alt="ZORKO fries"
              className="floaty absolute bottom-10 right-4 h-24 w-32 rounded-2xl object-cover shadow-2xl ring-2 ring-white/10"
            />
            <img
              src={IMAGES.momos}
              alt="ZORKO momos"
              className="floaty-slow absolute bottom-16 left-2 h-24 w-24 rounded-full object-cover shadow-2xl ring-2 ring-white/10"
            />
          </div>
        </div>
      </section>

      <div className="border-y border-[#ff6b00]/30 bg-[#ff6b00] py-3 text-[#0d0b0a] overflow-hidden">
        <div className="marquee-track font-display text-2xl tracking-[0.18em]">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex items-center">
              {[
                "FASTEST GROWING VEG QSR",
                "500+ OUTLETS",
                "SHARK TANK INDIA",
                "FORBES 30 UNDER 30",
                "80+ PURE VEG DISHES",
                "NO ROYALTY FRANCHISE",
                "BRAND OF FOOD LOVERS",
              ].map((t) => (
                <span key={t + i} className="mx-6 inline-flex items-center gap-6">
                  {t}
                  <span className="text-white">✦</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <section className="relative border-b border-white/5 bg-[#14110f] py-10">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 sm:grid-cols-3 md:grid-cols-6 md:px-8">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="font-display text-4xl tracking-wide text-[#ff6b00] md:text-5xl">{s.value}</div>
              <div className="mt-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-stone-400">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="flex items-end justify-between gap-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ffb020]">House signatures</p>
              <h2 className="mt-2 font-display text-5xl tracking-wide md:text-7xl">Plates worth a pilgrimage</h2>
            </div>
            <a href="#menu" className="hidden items-center gap-2 text-sm font-semibold text-[#ff6b00] md:inline-flex">
              Full menu <ArrowRight className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-10 grid auto-rows-[180px] grid-cols-2 gap-3 md:auto-rows-[200px] md:grid-cols-4 lg:grid-cols-6">
            {SIGNATURES.map((s, i) => {
              const span =
                i === 0
                  ? "md:col-span-2 md:row-span-2 md:auto-rows-auto min-h-[200px] md:min-h-[412px]"
                  : i === 1
                    ? "md:col-span-2"
                    : "";
              return (
                <a
                  key={s.name}
                  href="#menu"
                  className={`group relative overflow-hidden rounded-3xl ${span}`}
                >
                  <img src={s.img} alt={s.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-4">
                    <span className="rounded-full bg-[#ff6b00] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide">
                      {s.tag}
                    </span>
                    <h3 className="mt-2 font-semibold leading-tight text-white">{s.name}</h3>
                    <p className="font-display text-xl text-[#ffb020]">₹{s.price}</p>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      </section>

      <section id="why" className="relative bg-gradient-to-b from-[#fff8f0] to-[#ffe8cc] py-24 text-stone-900">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ff6b00]">Franchise Advantage</p>
            <h2 className="mt-3 font-display text-5xl tracking-wide text-stone-900 md:text-7xl">Why choose ZORKO?</h2>
            <p className="mt-4 text-stone-600">
              From low investment and marketing support to operational guidance and technology-driven solutions, ZORKO provides everything needed to build a successful food business.
            </p>
          </div>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {WHY.map((w) => (
              <article
                key={w.title}
                className="group rounded-3xl bg-white p-6 shadow-[0_20px_50px_-24px_rgba(255,107,0,0.45)] ring-1 ring-orange-100 transition hover:-translate-y-1 hover:shadow-[0_28px_60px_-20px_rgba(255,107,0,0.55)]"
              >
                <WhyIcon name={w.icon} />
                <h3 className="mt-5 text-lg font-bold leading-snug text-[#e25100]">{w.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-stone-600">{w.text}</p>
              </article>
            ))}
          </div>

          <p className="mx-auto mt-12 max-w-4xl text-center text-sm leading-relaxed text-stone-600">
            Our franchise model is designed to help aspiring entrepreneurs confidently enter the food industry and create long-term business growth. Chef-less kitchens, manufacturer-direct ingredients, ₹25,000 launch marketing, and complete creative freedom — this is how ZORKO scales with its partners.
          </p>
        </div>
      </section>

      <section id="menu" className="relative py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ffb020]">80+ Pure Veg Dishes</p>
              <h2 className="mt-2 font-display text-5xl tracking-wide md:text-7xl">The Menu</h2>
              <p className="mt-3 max-w-xl text-stone-400">
                Burgers, pizza, momos, mojitos and everything in between — researched recipes, unique sauces, and freedom to customise.
              </p>
            </div>
            <div className="relative w-full md:w-80">
              <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search dishes…"
                className="w-full rounded-full border border-white/10 bg-white/5 py-3 pl-11 pr-4 text-sm outline-none placeholder:text-stone-500 focus:border-[#ff6b00]"
              />
            </div>
          </div>

          <div className="menu-scroll mt-8 flex gap-2 overflow-x-auto pb-2">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCat(c.id)}
                className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${
                  cat === c.id ? "bg-[#ff6b00] text-white" : "bg-white/5 text-stone-300 hover:bg-white/10"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="mt-6 grid gap-3 md:grid-cols-3">
            <div className="rounded-2xl border border-[#ff6b00]/30 bg-gradient-to-r from-[#ff6b00]/20 to-transparent p-4">
              <p className="font-display text-xl tracking-wide text-[#ffb020]">Cheese Injector · ₹30</p>
              <p className="text-xs text-stone-300">Inject molten cheese into any burger. Grill any burger ₹30. Double cheese slice ₹30.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="font-display text-xl tracking-wide text-white">Mojito extras · ₹30</p>
              <p className="text-xs text-stone-300">Add a float or an injector to any mojito. Ice-cream scoop on shakes & cold coffee ₹25.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="font-display text-xl tracking-wide text-white">Maggi add-ons</p>
              <p className="text-xs text-stone-300">Cheese 25gm ₹30 · Butter 10gm ₹10. Pasta baked upgrade ₹169.</p>
            </div>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActive(item)}
                className="card-shine group overflow-hidden rounded-3xl bg-[#1a1613] text-left ring-1 ring-white/8 transition hover:-translate-y-1 hover:ring-[#ff6b00]/50"
              >
                <div className="relative h-44 overflow-hidden">
                  <img src={item.image} alt={item.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1613] to-transparent" />
                  <div className="absolute left-3 top-3 flex flex-wrap gap-1">
                    {item.badges?.map((b) => (
                      <BadgePill key={b} kind={b} />
                    ))}
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-semibold leading-snug text-white">{item.name}</h3>
                    <div className="shrink-0 text-right">
                      <div className="font-display text-2xl leading-none text-[#ff6b00]">₹{item.price}</div>
                      {item.baked && <div className="text-[10px] text-stone-400">Baked ₹{item.baked}</div>}
                    </div>
                  </div>
                  <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-stone-400">{item.desc}</p>
                  {item.extra && (
                    <p className="mt-2 text-[11px] text-[#ffb020]">
                      {item.extraLabel} +₹{item.extra}
                    </p>
                  )}
                </div>
              </button>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="py-16 text-center text-stone-500">No dishes match that search. Try another flavour.</p>
          )}
        </div>
      </section>

      <section id="offers" className="relative overflow-hidden py-24">
        <div className="absolute inset-0 bg-gradient-to-br from-[#ff6b00]/20 via-transparent to-[#ffb020]/10" />
        <div className="relative mx-auto max-w-7xl px-5 md:px-8">
          <div className="grid gap-8 lg:grid-cols-5">
            <div className="overflow-hidden rounded-[2rem] bg-[#1a1613] ring-1 ring-white/10 lg:col-span-3">
              <div className="bg-[#ff6b00] px-8 py-6">
                <p className="font-script text-4xl text-white">Try Our Meals</p>
                <h3 className="font-display text-3xl tracking-wide text-[#0d0b0a] md:text-4xl">Birthday · Kitty · Celebration</h3>
              </div>
              <div className="grid gap-4 p-6 sm:grid-cols-2">
                {PACKAGE_ITEMS.map((p) => (
                  <div key={p.name} className="flex items-center gap-3 rounded-2xl bg-white/5 p-3">
                    <img src={p.img} alt="" className="h-14 w-14 rounded-xl object-cover" />
                    <div>
                      <div className="font-display text-xl text-[#ff6b00]">{p.qty}</div>
                      <div className="text-sm text-stone-200">{p.name}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between border-t border-white/10 px-8 py-5">
                <p className="text-sm text-stone-400">Feeds a full celebration table.</p>
                <div className="rounded-full bg-white px-5 py-2 font-display text-3xl tracking-wide text-[#ff6b00]">₹1999</div>
              </div>
            </div>

            <div className="flex flex-col justify-between overflow-hidden rounded-[2rem] bg-[#0d0b0a] ring-1 ring-[#ff6b00]/40 lg:col-span-2">
              <div className="p-8">
                <p className="text-xs font-bold uppercase tracking-[0.3em] text-[#ffb020]">Monday & Thursday</p>
                <h3 className="mt-2 font-display text-6xl leading-none tracking-wide text-white">
                  BUY 1
                  <br />
                  <span className="text-[#ff6b00]">GET 1</span>
                  <br />
                  FREE
                </h3>
                <p className="mt-4 text-sm text-stone-400">Order now on these hero dishes — every Monday & Thursday.</p>
                <ul className="mt-6 space-y-3">
                  {BOGO.map((b) => (
                    <li key={b} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-[#ff6b00]" /> {b}
                    </li>
                  ))}
                </ul>
              </div>
              <img src={IMAGES.pizza} alt="" className="h-40 w-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      <section id="story" className="relative border-y border-white/5 bg-[#100e0c] py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="grid items-end gap-8 lg:grid-cols-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ffb020]">From zero to a movement</p>
              <h2 className="mt-2 font-display text-5xl tracking-wide md:text-7xl">The ZORKO Story</h2>
              <p className="mt-4 max-w-xl text-stone-400">
                Eighteen chapters. One family name. A café brand built on belief, 14-hour days, and the refusal to quit.
              </p>
            </div>
            <p className="font-serif text-2xl italic text-stone-300 lg:text-right">
              “It became more than a name — it became a mindset.”
            </p>
          </div>

          <div className="mt-12 grid gap-10 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <div className="relative overflow-hidden rounded-[2rem] bg-[#1a1613] p-8 ring-1 ring-white/10">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-[#ff6b00]/15 px-3 py-1 text-xs font-bold uppercase tracking-widest text-[#ffb020]">
                    {ch.era}
                  </span>
                  <span className="font-display text-5xl text-white/10">{String(ch.n).padStart(2, "0")}</span>
                </div>
                <p className="mt-6 text-xs uppercase tracking-[0.3em] text-[#ff6b00]">{ch.year}</p>
                <h3 className="mt-2 font-display text-4xl tracking-wide md:text-5xl">{ch.title}</h3>
                <p className="mt-5 text-base leading-relaxed text-stone-300">{ch.body}</p>
                <div className="mt-8 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setChapter((c) => Math.max(0, c - 1))}
                    className="rounded-full border border-white/15 p-2 hover:bg-white/10"
                    aria-label="Previous chapter"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setChapter((c) => Math.min(STORY.length - 1, c + 1))}
                    className="rounded-full border border-white/15 p-2 hover:bg-white/10"
                    aria-label="Next chapter"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                  <span className="ml-2 text-sm text-stone-500">
                    Chapter {chapter + 1} / {STORY.length}
                  </span>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-6 lg:grid-cols-6">
                {STORY.map((s, i) => (
                  <button
                    key={s.n}
                    type="button"
                    onClick={() => setChapter(i)}
                    className={`rounded-2xl p-3 text-left transition ${
                      i === chapter ? "bg-[#ff6b00] text-white" : "bg-white/5 text-stone-400 hover:bg-white/10"
                    }`}
                  >
                    <div className="font-display text-xl leading-none">{String(s.n).padStart(2, "0")}</div>
                    <div className="mt-1 line-clamp-2 text-[10px] font-medium leading-tight">{s.title}</div>
                  </button>
                ))}
              </div>
              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                {[
                  { k: "Shark Tank India", v: "Season 3" },
                  { k: "Forbes", v: "30 Under 30" },
                  { k: "Customer love", v: "400+ videos" },
                ].map((a) => (
                  <div key={a.k} className="rounded-2xl border border-white/10 p-5">
                    <Award className="h-5 w-5 text-[#ffb020]" />
                    <div className="mt-3 text-xs uppercase tracking-widest text-stone-500">{a.k}</div>
                    <div className="font-display text-2xl">{a.v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="presence" className="relative py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ffb020]">Across India</p>
              <h2 className="mt-2 font-display text-5xl tracking-wide md:text-7xl">500+ outlets. Still growing.</h2>
              <p className="mt-5 text-stone-400">
                From Gujarat and Maharashtra to Assam, Jammu & Kashmir and Andaman & Nicobar — ZORKO has built a growing presence across India. 250+ cities. 24+ states. 4+ union territories.
              </p>
              <div className="mt-8 flex flex-wrap gap-2">
                {CITIES.map((c) => (
                  <span key={c} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-stone-300">
                    <MapPin className="mr-1 inline h-3 w-3 text-[#ff6b00]" />
                    {c}
                  </span>
                ))}
                <span className="rounded-full bg-[#ff6b00] px-3 py-1 text-xs font-semibold">+230 more cities</span>
              </div>
            </div>
            <div className="relative">
              <img src={IMAGES.cafe} alt="Café ambience" className="h-[420px] w-full rounded-[2rem] object-cover" />
              <div className="absolute -bottom-6 -left-4 rounded-2xl bg-[#ff6b00] p-5 text-[#0d0b0a] shadow-2xl">
                <div className="font-display text-4xl">24+</div>
                <div className="text-xs font-bold uppercase tracking-widest">States</div>
              </div>
              <div className="absolute -right-3 top-8 rounded-2xl bg-white p-5 text-stone-900 shadow-2xl">
                <div className="font-display text-4xl">4+</div>
                <div className="text-xs font-bold uppercase tracking-widest">Union Territories</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden">
        <img src={IMAGES.friends} alt="Friends sharing food" className="h-[380px] w-full object-cover md:h-[460px]" />
        <div className="absolute inset-0 bg-[#0d0b0a]/70" />
        <div className="absolute inset-0 flex items-center">
          <div className="mx-auto max-w-3xl px-6 text-center">
            <Play className="mx-auto h-12 w-12 text-[#ff6b00]" />
            <h3 className="mt-4 font-display text-4xl tracking-wide md:text-6xl">400+ video testimonials</h3>
            <p className="mt-3 text-stone-300">
              Real customers. Real tables. Real love. Beyond the numbers, this is what makes us proud.
            </p>
          </div>
        </div>
      </section>

      <section id="franchise" className="relative bg-gradient-to-b from-[#fff8f0] to-white py-24 text-stone-900">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-8 lg:grid-cols-2">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.4em] text-[#ff6b00]">Partner with us</p>
            <h2 className="mt-2 font-display text-5xl tracking-wide md:text-6xl">Own a ZORKO café</h2>
            <p className="mt-4 text-stone-600">
              A chef-less, low-wastage, high-flavour franchise built for first-time entrepreneurs. No royalty. No profit sharing. Full creative freedom.
            </p>
            <ul className="mt-8 space-y-4">
              {[
                "Zero royalty & zero profit sharing — you keep the profits",
                "Manufacturer-direct sauces, syrups & premixes",
                "Chef-less kitchen — no highly trained staff required",
                "₹25,000 digital & influencer marketing budget",
                "End-to-end tech: ordering, inventory, training",
                "80+ pure veg dishes with menu customisation",
              ].map((t) => (
                <li key={t} className="flex gap-3 text-sm">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#ff6b00] text-white">
                    <Check className="h-3 w-3" />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
            <div className="mt-10 grid grid-cols-3 gap-3">
              {[
                { n: "0%", l: "Royalty" },
                { n: "0%", l: "Wastage model" },
                { n: "80+", l: "Veg SKUs" },
              ].map((x) => (
                <div key={x.l} className="rounded-2xl bg-[#0d0b0a] p-4 text-center text-white">
                  <div className="font-display text-3xl text-[#ff6b00]">{x.n}</div>
                  <div className="text-[10px] uppercase tracking-widest text-stone-400">{x.l}</div>
                </div>
              ))}
            </div>
          </div>

          <form onSubmit={onSubmit} className="rounded-[2rem] bg-[#0d0b0a] p-8 text-white shadow-2xl">
            {sent ? (
              <div className="flex h-full min-h-[420px] flex-col items-center justify-center text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#ff6b00]">
                  <Check className="h-8 w-8" />
                </div>
                <h3 className="mt-6 font-display text-4xl">We’ve got your spark.</h3>
                <p className="mt-3 max-w-sm text-stone-400">
                  A ZORKO partner success manager will reach out shortly. Meanwhile, dream about that first burger coming off the grill.
                </p>
              </div>
            ) : (
              <>
                <h3 className="font-display text-3xl tracking-wide">Start your enquiry</h3>
                <p className="mt-1 text-sm text-stone-400">Tell us where you want to open. We’ll take it from there.</p>
                <div className="mt-6 grid gap-4">
                  <input name="name" required placeholder="Full name" className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-[#ff6b00]" />
                  <input name="phone" required type="tel" placeholder="Phone number" className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-[#ff6b00]" />
                  <input name="city" required placeholder="City / preferred location" className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-[#ff6b00]" />
                  <select name="type" className="rounded-xl border border-white/10 bg-[#1a1613] px-4 py-3 text-sm outline-none focus:border-[#ff6b00]">
                    <option value="franchise">Franchise enquiry</option>
                    <option value="outlet">Existing outlet support</option>
                    <option value="party">Party / celebration booking</option>
                    <option value="other">Something else</option>
                  </select>
                  <textarea name="message" rows={4} placeholder="Tell us a little about yourself" className="resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-[#ff6b00]" />
                  <button type="submit" className="pulse-glow rounded-full bg-[#ff6b00] py-3.5 text-sm font-bold uppercase tracking-widest hover:bg-[#e25100]">
                    Submit enquiry
                  </button>
                </div>
              </>
            )}
          </form>
        </div>
      </section>

      <section className="border-t border-white/5 bg-[#14110f] py-16">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { t: "Taste without the chef", d: "Premixes and systems mean consistent flavour in every city — without a professional kitchen brigade." },
              { t: "Built by founders who cooked", d: "The Nahar brothers ran the counters, the recipes and the 14-hour days. That grit is in the brand." },
              { t: "A national veg movement", d: "Pure vegetarian, wildly flavourful, proudly Indian. From the first warehouse to 500+ doors." },
            ].map((c) => (
              <div key={c.t} className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/8">
                <Zap className="h-5 w-5 text-[#ff6b00]" />
                <h3 className="mt-4 font-semibold">{c.t}</h3>
                <p className="mt-2 text-sm text-stone-400">{c.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-[#0d0b0a] py-14">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 md:grid-cols-4 md:px-8">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-4 max-w-sm text-sm text-stone-400">
              Brand of food lovers. India’s fastest & largest growing veg QSR chain. From zero to a movement — and the journey continues.
            </p>
            <div className="mt-6 flex gap-3 text-xs text-stone-500">
              <span className="inline-flex items-center gap-1">
                <Phone className="h-3.5 w-3.5" /> Franchise helpline
              </span>
              <span className="inline-flex items-center gap-1">
                <IndianRupee className="h-3.5 w-3.5" /> Affordable. Premium.
              </span>
            </div>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.25em] text-[#ffb020]">Explore</h4>
            <div className="mt-4 flex flex-col gap-2 text-sm text-stone-400">
              {NAV.map((n) => (
                <a key={n.href} href={n.href} className="hover:text-white">
                  {n.label}
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.25em] text-[#ffb020]">Visit</h4>
            <p className="mt-4 text-sm text-stone-400">
              500+ outlets across 250+ cities.
              <br />
              Gujarat · Maharashtra · Assam
              <br />
              J&K · Andaman & Nicobar · and more
            </p>
            <a href="#franchise" className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[#ff6b00]">
              Become a partner <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
        <div className="mx-auto mt-12 flex max-w-7xl flex-col items-center justify-between gap-3 border-t border-white/10 px-5 pt-6 text-xs text-stone-500 md:flex-row md:px-8">
          <p>© {new Date().getFullYear()} ZORKO. Brand of food lovers. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Made with <Heart className="h-3 w-3 text-[#ff6b00]" /> for food lovers across India
          </p>
        </div>
      </footer>

      {active && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm md:items-center" onClick={() => setActive(null)}>
          <div
            className="relative w-full max-w-lg overflow-hidden rounded-3xl bg-[#1a1613] ring-1 ring-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <img src={active.image} alt={active.name} className="h-56 w-full object-cover" />
            <button
              type="button"
              onClick={() => setActive(null)}
              className="absolute right-4 top-4 rounded-full bg-black/50 p-2"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="p-6">
              <div className="flex flex-wrap gap-1">
                {active.badges?.map((b) => (
                  <BadgePill key={b} kind={b} />
                ))}
              </div>
              <div className="mt-3 flex items-start justify-between gap-4">
                <h3 className="font-display text-4xl tracking-wide">{active.name}</h3>
                <div className="font-display text-4xl text-[#ff6b00]">₹{active.price}</div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-stone-300">{active.desc}</p>
              {active.extra && (
                <p className="mt-3 rounded-xl bg-[#ff6b00]/10 px-3 py-2 text-sm text-[#ffb020]">
                  {active.extraLabel} +₹{active.extra}
                </p>
              )}
              {active.baked && (
                <p className="mt-2 text-sm text-stone-400">Baked version ₹{active.baked}</p>
              )}
              <a href="#franchise" onClick={() => setActive(null)} className="mt-6 inline-flex w-full items-center justify-center rounded-full bg-[#ff6b00] py-3 text-sm font-bold uppercase tracking-widest">
                Find it at a ZORKO near you
              </a>
            </div>
          </div>
        </div>
      )}

      <a
        href="#franchise"
        className="fixed bottom-5 right-5 z-40 hidden items-center gap-2 rounded-full bg-[#ff6b00] px-4 py-3 text-xs font-bold uppercase tracking-widest text-white shadow-xl shadow-orange-700/40 md:inline-flex"
      >
        <Star className="h-4 w-4" /> Get Franchise
      </a>
    </div>
  );
}
